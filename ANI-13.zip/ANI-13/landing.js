/* Switch between the landing-page login and register panels. */
function showAuthPanel(which) {
    const login = document.getElementById('landingLogin');
    const register = document.getElementById('landingRegister');
    const showLogin = which === 'login';

    login.classList.toggle('is-active', showLogin);
    register.classList.toggle('is-active', !showLogin);
    login.setAttribute('aria-hidden', String(!showLogin));
    register.setAttribute('aria-hidden', String(showLogin));

    const activeForm = showLogin ? login : register;
    const firstInput = activeForm.querySelector('input');
    if (firstInput) {
        window.setTimeout(() => firstInput.focus({ preventScroll: true }), 350);
    }
}

document.querySelectorAll('.auth-toggle').forEach(button => {
    button.addEventListener('click', () => showAuthPanel(button.dataset.show));
});
