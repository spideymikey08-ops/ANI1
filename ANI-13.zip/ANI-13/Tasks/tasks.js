/* Tasks page logic — Plot cards layout + Table view toggle */

let allTasks = [];
let allPlots = [];
let currentHistoryPlotId = null;
let historyActiveFilter = 'all';

const taskBody = document.getElementById('taskBody');
const taskForm = document.getElementById('taskForm');
const taskPlot = document.getElementById('taskPlot');
const taskDate = document.getElementById('taskDate');

const taskPlotsGrid = document.getElementById('taskPlotsGrid');
const taskTableView = document.getElementById('taskTableView');
const viewCardsBtn = document.getElementById('viewCardsBtn');
const viewTableBtn = document.getElementById('viewTableBtn');

const plotTaskHistoryModal = document.getElementById('plotTaskHistoryModal');
const plotQuickDetailsModal = document.getElementById('plotQuickDetailsModal');

let currentViewMode = localStorage.getItem('ani_tasks_view') || 'cards';

/* ---------- View Mode Toggle ---------- */

function setViewMode(mode) {
    currentViewMode = mode;
    localStorage.setItem('ani_tasks_view', mode);

    if (mode === 'cards') {
        viewCardsBtn.classList.add('active');
        viewTableBtn.classList.remove('active');
        taskPlotsGrid.hidden = false;
        taskTableView.hidden = true;
    } else {
        viewTableBtn.classList.add('active');
        viewCardsBtn.classList.remove('active');
        taskPlotsGrid.hidden = true;
        taskTableView.hidden = false;
    }
}

viewCardsBtn.addEventListener('click', () => setViewMode('cards'));
viewTableBtn.addEventListener('click', () => setViewMode('table'));

/* ---------- Helpers ---------- */

function escapeHtml(str) {
    return String(str || '').replace(/[&<>"']/g, m => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[m]);
}

function getPlotVisualStatus(p) {
    if (p.status === 'Maintenance') return 'Maintenance';
    if (p.status === 'Available' || (!p.crop_name && p.status !== 'Occupied')) return 'Available';
    if (p.days_to_harvest !== null && p.days_to_harvest !== undefined) {
        const d = Number(p.days_to_harvest);
        if (d <= 14 && d >= -5) return 'Ripening';
    }
    return 'Planted';
}

function getTaskIcon(type) {
    const icons = {
        'Water': '💧',
        'Fertilize': '🌾',
        'Weed': '🌿',
        'Pest Control': '🐛',
        'Inspect': '🔍',
        'Other': '📝'
    };
    return icons[type] || '📝';
}

function getTaskDueMeta(dateStr) {
    if (!dateStr) return { label: '', cls: '' };
    const t = today();
    if (dateStr === t) return { label: 'Due Today', cls: 'due-today' };
    if (dateStr < t) return { label: `Overdue (${dateStr})`, cls: 'due-overdue' };
    return { label: `Due ${dateStr}`, cls: 'due-future' };
}

/* ---------- Table View Rendering (Preserved) ---------- */

function taskRow(t) {
    const row = cloneTemplate('tpl-task-row');
    row.dataset.id = t.id;
    row.classList.toggle('muted', Boolean(Number(t.done)));
    row.querySelector('input[type="checkbox"]').checked = Boolean(Number(t.done));

    fill(row, { plot: t.plot_name, task_type: t.task_type || 'Water', date: t.task_date });
    setBadge(row, 'crop', t.crop_type);
    return row;
}

/* ---------- Plot Card Rendering (Matching design mockup) ---------- */

function renderPlotTaskCard(p) {
    const plotTasks = allTasks.filter(t => t.plot_id == p.id);
    const pendingTasks = plotTasks.filter(t => !Number(t.done));
    const visualStatus = getPlotVisualStatus(p);

    const statusClassMap = {
        'Available': 'status-available',
        'Planted': 'status-planted',
        'Ripening': 'status-ripening',
        'Maintenance': 'status-maintenance'
    };
    const statusClass = statusClassMap[visualStatus] || 'status-available';

    const card = document.createElement('div');
    card.className = 'task-plot-card';
    card.dataset.plotId = p.id;

    // Planting subtitle
    const cropText = p.crop_name 
        ? `${escapeHtml(p.crop_name)}${p.variety ? ' (' + escapeHtml(p.variety) + ')' : ''}`
        : 'No current planting';

    // Pending tasks rows inside inset
    let tasksContent = '';
    if (pendingTasks.length > 0) {
        const rows = pendingTasks.slice(0, 2).map(t => {
            const due = getTaskDueMeta(t.task_date);
            const typeIcon = getTaskIcon(t.task_type);
            const typeClass = (t.task_type || 'Other').replace(/\s+/g, '-');

            return `
                <div class="inset-task-item">
                    <div class="task-item-lead">
                        <div class="task-icon-cube ${typeClass}">
                            ${typeIcon}
                        </div>
                        <div class="task-item-text">
                            <div class="task-name">${escapeHtml(t.task_type)}</div>
                            <span class="task-due-chip ${due.cls}">
                                <i class="fa-regular fa-clock"></i> ${due.label}
                            </span>
                        </div>
                    </div>
                    <button type="button" class="task-btn-complete" data-task-id="${t.id}" title="Mark completed">
                        <i class="fa-solid fa-check"></i>
                    </button>
                </div>
            `;
        }).join('');

        const moreLabel = pendingTasks.length > 2 
            ? `<div class="inset-more-tasks" data-plot-id="${p.id}">+${pendingTasks.length - 2} more pending...</div>` 
            : '';

        tasksContent = `
            <div class="inset-tasks-list">
                ${rows}
                ${moreLabel}
            </div>
        `;
    } else {
        tasksContent = `
            <div class="inset-empty-tasks">
                <span>✨ No pending tasks for this plot</span>
            </div>
        `;
    }

    card.innerHTML = `
        <!-- Card Header -->
        <div class="task-card-header">
            <div class="task-card-title-row">
                <h3 class="task-card-title">${escapeHtml(p.name)}</h3>
                <span class="plot-status-pill ${statusClass}">
                    <span class="status-dot"></span>
                    ${visualStatus}
                </span>
            </div>
            <div class="task-card-crop-sub">
                <span class="crop-icon">🌱</span>
                <span>${cropText}</span>
            </div>
        </div>

        <!-- Inset Pending Tasks Container -->
        <div class="task-card-inset">
            <div class="inset-header">
                <div class="inset-title">
                    <span class="inset-icon-box">
                        <i class="fa-solid fa-list-check"></i>
                    </span>
                    <span class="inset-heading">Pending Tasks</span>
                </div>
                <span class="pending-pill ${pendingTasks.length ? 'has-pending' : 'all-done'}">
                    ${pendingTasks.length ? `${pendingTasks.length} Pending` : 'All Done'}
                </span>
            </div>
            ${tasksContent}
        </div>

        <!-- Card Footer Actions -->
        <div class="task-card-footer">
            <button type="button" class="btn-card-add-task" data-plot-id="${p.id}" title="Schedule a task for this plot">
                + Add Task
            </button>
            <button type="button" class="btn-card-view-tasks" data-plot-id="${p.id}" title="View all tasks">
                <i class="fa-regular fa-square-check"></i> Tasks (${plotTasks.length})
            </button>
            <button type="button" class="btn-card-details" data-plot-id="${p.id}" title="Plot details">
                <i class="fa-solid fa-gear"></i> Details
            </button>
        </div>
    `;

    // 1-Click Complete Button
    card.querySelectorAll('.task-btn-complete').forEach(btn => {
        btn.addEventListener('click', async e => {
            e.stopPropagation();
            const taskId = btn.dataset.taskId;
            toggleTask(taskId, 1);
        });
    });

    // "+ Add Task" button -> pre-select in schedule form and smooth scroll
    const addTaskBtn = card.querySelector('.btn-card-add-task');
    if (addTaskBtn) {
        addTaskBtn.addEventListener('click', e => {
            e.stopPropagation();
            if (taskPlot) taskPlot.value = p.id;
            if (taskDate) taskDate.value = today();
            
            taskForm.scrollIntoView({ behavior: 'smooth', block: 'center' });
            const typeSelect = document.getElementById('taskType');
            if (typeSelect) typeSelect.focus();
            
            taskForm.parentElement.classList.add('highlight-form');
            setTimeout(() => taskForm.parentElement.classList.remove('highlight-form'), 1500);
        });
    }

    // "Tasks (X)" button
    const viewTasksBtn = card.querySelector('.btn-card-view-tasks');
    if (viewTasksBtn) {
        viewTasksBtn.addEventListener('click', e => {
            e.stopPropagation();
            openHistoryModal(p.id);
        });
    }

    // "More tasks" link
    const moreBtn = card.querySelector('.inset-more-tasks');
    if (moreBtn) {
        moreBtn.addEventListener('click', e => {
            e.stopPropagation();
            openHistoryModal(p.id);
        });
    }

    // "Details" button
    const detailsBtn = card.querySelector('.btn-card-details') || card.querySelector('.btn-details');
    if (detailsBtn) {
        detailsBtn.addEventListener('click', e => {
            e.stopPropagation();
            openPlotDetails(p);
        });
    }

    return card;
}

/* ---------- Plot Task History Modal ---------- */

function openHistoryModal(plotId) {
    const p = allPlots.find(x => x.id == plotId);
    if (!p) return;

    currentHistoryPlotId = plotId;
    document.getElementById('historyPlotTitle').textContent = p.name;
    document.getElementById('historyPlotId').value = p.id;
    document.getElementById('historyTaskDate').value = today();

    renderHistoryList();
    plotTaskHistoryModal.hidden = false;
}

function closeHistoryModal() {
    plotTaskHistoryModal.hidden = true;
    currentHistoryPlotId = null;
}

function renderHistoryList() {
    if (!currentHistoryPlotId) return;

    const plotTasks = allTasks.filter(t => t.plot_id == currentHistoryPlotId);
    let filtered = plotTasks;

    if (historyActiveFilter === 'pending') {
        filtered = plotTasks.filter(t => !Number(t.done));
    } else if (historyActiveFilter === 'completed') {
        filtered = plotTasks.filter(t => Number(t.done));
    }

    const listEl = document.getElementById('historyTasksList');
    const badgeEl = document.getElementById('historyTasksBadge');
    const pendingCount = plotTasks.filter(t => !Number(t.done)).length;
    badgeEl.textContent = `${pendingCount} Pending`;

    if (filtered.length === 0) {
        listEl.innerHTML = `
            <div class="task-empty-state">
                <p>No ${historyActiveFilter === 'all' ? '' : historyActiveFilter} tasks found.</p>
            </div>
        `;
        return;
    }

    listEl.innerHTML = '';
    filtered.forEach(task => {
        const isDone = Boolean(Number(task.done));
        const due = getTaskDueMeta(task.task_date);
        const icon = getTaskIcon(task.task_type);
        const iconClass = (task.task_type || 'Other').replace(/\s+/g, '-');

        const row = document.createElement('div');
        row.className = `history-task-row ${isDone ? 'is-done' : ''}`;

        row.innerHTML = `
            <div style="display:flex; align-items:center; gap:12px;">
                <input type="checkbox" ${isDone ? 'checked' : ''} class="history-toggle" data-task-id="${task.id}" title="${isDone ? 'Reopen task' : 'Mark done'}">
                <div class="task-icon-cube ${iconClass}" style="width:34px; height:34px; font-size:16px;">${icon}</div>
                <div>
                    <div style="font-weight:700; font-size:14px; color:#1e293b;">${escapeHtml(task.task_type)}</div>
                    <div style="font-size:12px; color:#64748b;">${due.label}</div>
                </div>
            </div>
            <button type="button" class="small danger history-delete-btn" data-task-id="${task.id}" title="Delete task">
                Delete
            </button>
        `;

        row.querySelector('.history-toggle').addEventListener('change', async e => {
            await toggleTask(task.id, e.target.checked ? 1 : 0);
            renderHistoryList();
        });

        row.querySelector('.history-delete-btn').addEventListener('click', async () => {
            await deleteTask(task.id);
            renderHistoryList();
        });

        listEl.appendChild(row);
    });
}

// History Tabs
document.querySelectorAll('.history-tab').forEach(tab => {
    tab.addEventListener('click', () => {
        document.querySelectorAll('.history-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        historyActiveFilter = tab.dataset.filter;
        renderHistoryList();
    });
});

document.getElementById('historyClose').addEventListener('click', closeHistoryModal);
plotTaskHistoryModal.addEventListener('click', e => {
    if (e.target === plotTaskHistoryModal) closeHistoryModal();
});

// Quick add inside history modal
document.getElementById('historyQuickTaskForm').addEventListener('submit', async e => {
    e.preventDefault();
    try {
        const fd = Object.fromEntries(new FormData(e.target));
        await post('Tasks/add_task.php', fd);
        toast('Task scheduled.');
        e.target.reset();
        document.getElementById('historyPlotId').value = currentHistoryPlotId;
        document.getElementById('historyTaskDate').value = today();
        await load();
        renderHistoryList();
    } catch (err) {
        toast(err.message, true);
    }
});

/* ---------- Quick Plot Details Modal ---------- */

function openPlotDetails(p) {
    document.getElementById('detailsPlotTitle').textContent = p.name;
    document.getElementById('detailsPlotStatus').textContent = p.status || 'Available';
    document.getElementById('detailsPlotCrop').textContent = p.crop_name || 'None';
    document.getElementById('detailsPlotVariety').textContent = p.variety || '—';
    document.getElementById('detailsPlotPlanted').textContent = p.planted_date || '—';
    document.getElementById('detailsPlotHarvest').textContent = p.expected_harvest_date || '—';
    document.getElementById('detailsPlotNotes').textContent = p.planting_notes || '—';

    plotQuickDetailsModal.hidden = false;
}

function closePlotDetails() {
    plotQuickDetailsModal.hidden = true;
}

document.getElementById('detailsClose').addEventListener('click', closePlotDetails);
plotQuickDetailsModal.addEventListener('click', e => {
    if (e.target === plotQuickDetailsModal) closePlotDetails();
});

/* ---------- Main Data Loading ---------- */

async function load() {
    try {
        const [t, p] = await Promise.all([
            api('Tasks/get_tasks.php'),
            api('Plots/get_plots.php')
        ]);

        allTasks = t.tasks || [];
        allPlots = p.plots || [];

        // 1. Render Table View
        render(taskBody, allTasks.map(taskRow));

        // 2. Render Plot Cards Grid (Design layout requested)
        taskPlotsGrid.innerHTML = '';
        if (allPlots.length === 0) {
            taskPlotsGrid.innerHTML = `
                <div class="empty-tasks-callout">
                    <p>No plots found. Create plots in the Plots page to organize your farm tasks.</p>
                    <a href="../Plots/plots.html" class="small-btn" style="text-decoration:none;">Go to Plots</a>
                </div>
            `;
        } else {
            allPlots.forEach(plot => {
                taskPlotsGrid.appendChild(renderPlotTaskCard(plot));
            });
        }

        // 3. Populate plot select in the schedule form
        if (taskPlot) {
            fillPlotSelect(taskPlot, allPlots, 'Select a plot');
        }
        if (taskDate && !taskDate.value) {
            taskDate.value = today();
        }
    } catch (e) {
        toast(e.message, true);
    }
}

/* ---------- Global Handlers ---------- */

if (taskForm) {
    taskForm.addEventListener('submit', async e => {
        e.preventDefault();
        try {
            const fd = Object.fromEntries(new FormData(taskForm));
            await post('Tasks/add_task.php', fd);
            toast('Task scheduled.');
            taskForm.reset();
            if (taskDate) taskDate.value = today();
            load();
        } catch (err) {
            toast(err.message, true);
        }
    });
}

async function toggleTask(id, done) {
    try {
        await post('Tasks/mark_done.php', { id, done });
        toast(done ? 'Task marked done.' : 'Task reopened.');
        await load();
    } catch (e) {
        toast(e.message, true);
    }
}

async function deleteTask(id) {
    if (!confirm('Delete this task?')) return;

    try {
        await post('Tasks/delete_task.php', { id });
        toast('Task deleted.');
        await load();
    } catch (e) {
        toast(e.message, true);
    }
}

taskBody.addEventListener('change', e => {
    if (e.target.dataset.action !== 'toggle') return;
    toggleTask(e.target.closest('tr').dataset.id, e.target.checked);
});

taskBody.addEventListener('click', e => {
    const button = e.target.closest('button[data-action="delete"]');
    if (button) deleteTask(button.closest('tr').dataset.id);
});

document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    if (!plotTaskHistoryModal.hidden) closeHistoryModal();
    else if (!plotQuickDetailsModal.hidden) closePlotDetails();
});

// Initialize
setViewMode(currentViewMode);
load();
