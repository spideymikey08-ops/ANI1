/* Login + Register forms embedded in the landing page. Requires core.js. */

const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');

if (loginForm) {
    loginForm.addEventListener('submit', async e => {
        e.preventDefault();
        const username = loginForm.querySelector('[name="username"]').value.trim();
        const password = loginForm.querySelector('[name="password"]').value;

        try {
            const r = await post('Auth/login.php', { username, password });
            localStorage.setItem('ani_user', r.full_name || '');
            localStorage.setItem('ani_role', r.role || 'user');

            if (r.role === 'admin') {
                window.location.href = urlFor('Admin/index.html');
            } else {
                window.location.href = urlFor('Dashboard/index.html');
            }
        } catch (err) {
            toast(err.message, true);
        }
    });
}

if (registerForm) {
    registerForm.addEventListener('submit', async e => {
        e.preventDefault();
        const field = name => registerForm.querySelector(`[name="${name}"]`).value;
        try {
            await post('Auth/register.php', {
                full_name: field('full_name').trim(),
                username: field('username').trim(),
                phone: field('phone').trim(),
                password: field('password'),
                confirm_password: field('confirm_password')
            });

            toast('Account created! Redirecting to login...');
            registerForm.reset();
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 1000);
        } catch (err) {
            toast(err.message, true);
        }
    });
}
